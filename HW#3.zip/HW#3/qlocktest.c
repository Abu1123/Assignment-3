#include "kernel/types.h"
#include "user/user.h"

int
main(void)
{
  int pid;

  for(int i = 0; i < 3; i++) {
    pid = fork();

    if(pid == 0) {
      for(int j = 0; j < 10; j++) {
        printf("Counter value: %d\n", qlocktest());
      }
      exit(0);
    }
  }

  for(int i = 0; i < 3; i++) {
    wait(0);
  }

  printf("QLock test completed!\n");
  printf("30 counter updates attempted by 3 processes.\n");

  exit(0);
}
