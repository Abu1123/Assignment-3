#include "types.h"
#include "param.h"
#include "spinlock.h"

#define HAS_LOCK 1
#define MUST_WAIT 0

struct qlock {
  struct spinlock lk;
  volatile uint flags[NCPU];
  uint slots[NCPU];
  uint tail;
};

void initqlock(struct qlock *q, char *name);
void acquireq(struct qlock *q);
void releaseq(struct qlock *q);

extern struct qlock testqlock;
