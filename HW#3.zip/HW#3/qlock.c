#include "types.h"
#include "riscv.h"
#include "qlock.h"
#include "defs.h"

struct qlock testqlock;

void
initqlock(struct qlock *q, char *name)
{
  initlock(&q->lk, name);

  q->tail = 0;

  for(int i = 0; i < NCPU; i++) {
    q->flags[i] = MUST_WAIT;
    q->slots[i] = 0;
  }

  q->flags[0] = HAS_LOCK;
}

void
acquireq(struct qlock *q)
{
  uint slot;
  int cpu;

  push_off();
  cpu = cpuid();

  acquire(&q->lk);

  slot = q->tail;
  q->tail = (q->tail + 1) % NCPU;
  q->slots[cpu] = slot;

  release(&q->lk);

  while(q->flags[slot] != HAS_LOCK)
    ;
}

void
releaseq(struct qlock *q)
{
  uint slot;
  uint next;
  int cpu;

  cpu = cpuid();
  slot = q->slots[cpu];
  next = (slot + 1) % NCPU;

  q->flags[slot] = MUST_WAIT;
  q->flags[next] = HAS_LOCK;

  pop_off();
}
